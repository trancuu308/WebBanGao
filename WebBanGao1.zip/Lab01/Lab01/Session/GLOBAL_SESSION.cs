﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab01.Session
{
    public class GLOBAL_SESSION
    {
        public static string USER_SESSION = "User Session";
        public static string Admin_SESSION = "Admin Session";
        public static string CART = "cart";
    }
}