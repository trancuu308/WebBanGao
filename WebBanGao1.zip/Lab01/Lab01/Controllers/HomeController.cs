﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;
using PagedList;

namespace Lab01.Controllers
{
    public class HomeController : Controller
    {
        Shop1Entities _db =  new Shop1Entities();
        // GET: Home
        public ActionResult Index(int? page)
        {
            return View(_db.Products.OrderBy(a => a.ProductDate).ToList().Take(36).ToPagedList(page ?? 1,9));
        }
        public ActionResult Delivery()
        { return View(); }
        public ActionResult AboutUs()
        {
            return View();
        }
        public ActionResult Refresh()
        {
            return View(_db.Products.ToList());
        }
        public ActionResult PhanLoai(int? page,int idcate)
        {
            
            List<Product> loaisp = _db.Products.Where(s => s.IDCategory == idcate).ToList();
            return View(loaisp.ToList().ToPagedList(page ?? 1,9));
        }
        public ActionResult Contact()
        {
            return View(_db.Products.ToList());
        }
        public ActionResult Detail(int id)
        {
            Product pro = _db.Products.SingleOrDefault(s => s.IDProduct == id);
            
            return View(pro);
        }
    }
}