﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;
using Lab01.Session;

namespace Lab01.Controllers
{
    public class LoginController : Controller
    {

        Shop1Entities _db = new Shop1Entities();
        // GET: Login
        public ActionResult Index()
        {
            ViewBag.LoginError = TempData["LoginError"];
            return View();
        }
        [HttpPost]
        public ActionResult Index(string account, string password)
        {
            var user = _db.Users.Where(m => m.Email == account && m.Password == password).FirstOrDefault();
         
            if (account != null && password != null && user != null)
            {
                if(account == "admin@gmail.com")
                {
                    return RedirectToAction("Index", "Product" ,new { Area = "admin" });
                }
               
                Session.Add(GLOBAL_SESSION.USER_SESSION, user);
                var cart = Session[GLOBAL_SESSION.CART] as Cart;
                if (cart != null)
                {
                    return RedirectToAction("CheckOut", "ShoppingCart");
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }

            }
            
            ViewBag.Error = "Email or password is incorrect. Please reenter!";
            return View();
        }
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(User _user)
        {
            if (ModelState.IsValid)
            {
                var check = _db.Users.FirstOrDefault(s => s.Email == _user.Email);
                if (check == null)
                {
                    _db.Configuration.ValidateOnSaveEnabled = false;
                    _db.Users.Add(_user);
                    _db.SaveChanges();
                    return RedirectToAction("Index");
                }
                else
                {
                    ViewBag.error = " Email already exists User another email please";
                    return View();

                }
            }
            return View();
        }
        public ActionResult LogOut()
        {
            Session.Abandon();
            return RedirectToAction("Index", "Home"); // me thod login la index
        }
    }
}
    