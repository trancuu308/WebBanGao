﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;
using Lab01.Session;
namespace Lab01.Controllers
{
    public class ShoppingCartController : Controller
    {
        private readonly Shop1Entities context = new Shop1Entities();
        public ActionResult Index()
        {
            ViewBag.LoiSoLuong = TempData["LoiSoLuong"] as string;
            ViewBag.ThongBaoTrong = TempData["ThongBaoTrong"] as string;
            var cart = Session[GLOBAL_SESSION.CART] as Cart;
            Cart listItem = new Cart();
            if (cart != null && cart.Items.Count > 0)
            {
                listItem = cart;
            }
            else
            {
                listItem.Items = new List<CartItem>();
                ViewBag.GioHangTrong = "Hiện Tại Chưa Chọn Sản Phẩm, mời quý khách lựa chọn sản phẩm!!";
            }

            return View(listItem);
        }
        [HttpPost]
        public ActionResult Increase(int id, int currentQtt = 1, int quantity = 1)
        {
            var f = context.Products.FirstOrDefault(m => m.IDProduct == id);
            var cart = Session[GLOBAL_SESSION.CART] as Cart;
            foreach (var item in cart.Items)
            {
                if (item._shopping_product.IDProduct == f.IDProduct)
                {
                    if (currentQtt < f.Quantity)
                        item._shopping_quantity += quantity;
                    else
                    {
                        TempData["LoiSoLuong"] = "<script>alert('Sản Phẩm tạm hết , vui lòng chọn Sản phẩm khác');</script>";
                        return RedirectToAction("Index");
                    }
                    //TODO
                }
            }
            Session[GLOBAL_SESSION.CART] = cart;
            return RedirectToAction("Index");
        }
        [HttpPost]
        public ActionResult Decrease(int id, int quantity, int currentQtt)
        {

            var f = context.Products.FirstOrDefault(m => m.IDProduct == id);
            var cart = Session[GLOBAL_SESSION.CART] as Cart;
            foreach (var item in cart.Items)
            {
                if (item._shopping_product.IDProduct == f.IDProduct)
                {
                    if (currentQtt > 1)
                        item._shopping_quantity -= quantity;
                    else
                    {
                        TempData["LoiSoLuong"] = "<script>alert('Không thể mua sản phẩm ');</script>";
                    }
                    //TODO
                }
            }
            Session[GLOBAL_SESSION.CART] = cart;
            return RedirectToAction("Index");


        }
        [HttpPost]
        public ActionResult Delete(int id)
        {
            var cart = Session[GLOBAL_SESSION.CART] as Cart;
            cart.Items.RemoveAll(x => x._shopping_product.IDProduct == id);
            Session[GLOBAL_SESSION.CART] = cart;
            return RedirectToAction("Index");
        }
        public ActionResult Add(int id, int quantity)
        {
            var cart = Session[GLOBAL_SESSION.CART] as Cart;
            var f = context.Products.FirstOrDefault(x => x.IDProduct == id);
            if (cart != null)
            {
                var listItem = cart.Items as List<CartItem>;
                if (listItem.Exists(m => m._shopping_product.IDProduct == id))
                {
                    foreach (var item in listItem)
                    {
                        if (item._shopping_product.IDProduct == f.IDProduct)
                        {
                            if (item._shopping_quantity < f.Quantity)
                                item._shopping_quantity += quantity;
                            else
                            {
                                TempData["LoiSoLuong"] = "<script>alert('Sản phẩm tạm hết , vui lòng chọn Sản phẩm khác ');</script>";
                                return RedirectToAction("Index");
                            }
                            //TODO
                        }
                    }
                }
                else
                {
                    CartItem cItem = new CartItem { _shopping_product = f, _shopping_quantity = quantity };
                    listItem.Add(cItem);
                }
                cart.Items = listItem;
                Session[GLOBAL_SESSION.CART] = cart;
            }
            else
            {
                cart = new Cart();
                List<CartItem> listItem = new List<CartItem>();
                CartItem cItem = new CartItem();
                cItem._shopping_product = f;
                cItem._shopping_quantity = quantity;
                listItem.Add(cItem);

                cart.Items = listItem;

                Session[GLOBAL_SESSION.CART] = cart;

            }
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult CheckOut()
        {
            User user = (User)Session[GLOBAL_SESSION.USER_SESSION];
            if (user == null)
            {
                TempData["LoginError"] = "<script>alert('Mời Đăng Nhập Để thanh toán');</script>";
                return RedirectToAction("Index", "Login");
            }
            Cart cart = (Cart)Session[GLOBAL_SESSION.CART];
            if (cart == null)
            {
                TempData["ThongBaoTrong"] = "<script>alert('Bạn Chưa Chọn Sản Phẩm nào, Nên Không Thể Thanh Toán');</script>";
                return RedirectToAction("Index");
            }
            decimal? totalAmount = 0;
            if (user != null)
            {
                ViewBag.SDT = context.Users.Where(m => m.Email == user.Email).FirstOrDefault().Phone_Cus;
                ViewBag.Address = context.Users.Where(m => m.Email == user.Email).FirstOrDefault().Address_Cus;
                ViewBag.User = user;

                ViewBag.Cart = cart;
                foreach (var item in cart.Items)
                {
                    totalAmount += item._shopping_quantity * item._shopping_product.UnitPrice;
                }
                TempData["ToTalAmount"] = totalAmount;
            }

            return View();
        }
        [HttpPost]
        public ActionResult CheckOut(decimal totalAmount)
        {
            User user = (User)Session[GLOBAL_SESSION.USER_SESSION];
            Cart cart = (Cart)Session[GLOBAL_SESSION.CART];
            List<OrderDetail> orderDetails = new List<OrderDetail>();
            foreach (var item in cart.Items)
            {
                OrderDetail detail = new OrderDetail()
                {
                    IDProduct = item._shopping_product.IDProduct,
                    Quantity = item._shopping_quantity,
                    UnitPriceSale = item._shopping_product.UnitPrice
                };
                orderDetails.Add(detail);
            }
            Order order = new Order()
            {
                Amount = Convert.ToInt32(totalAmount),
                IDUser = context.Users.Where(m => m.Email == user.Email).FirstOrDefault().IDUser,

                OrderDate = DateTime.Now,
                OrderDetails = orderDetails,
            };
            context.Orders.Add(order);
            context.SaveChanges();
            Session[GLOBAL_SESSION.CART] = null;
            return RedirectToAction("Index", "Home");
        }
    }
}
