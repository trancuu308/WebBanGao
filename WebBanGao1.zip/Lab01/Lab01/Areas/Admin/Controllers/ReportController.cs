﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using Lab01.Models;

namespace Lab01.Areas.Admin.Controllers
{
    public class ReportController : Controller
    {
      Shop1Entities _database = new Shop1Entities();
        // GET: Admin/Report
        [HttpGet]
        public ActionResult Index(string currentFilter, string searchString, int? page)
        {
            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewBag.CurrentFilter = searchString;

            var orderDetails = from s in _database.OrderDetails
                               select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                orderDetails = orderDetails.Where(s => s.Product.ProductDate.Value.Month.ToString() == searchString);
            }
            int pageSize = 6;
            int pageNumber = (page ?? 1);
            var lstProduct = orderDetails.ToList();
            int totalQuantity = 0;
            decimal totalPrice = 0;
            foreach (var orderDetail in lstProduct)
            {
                totalQuantity += orderDetail.Quantity.Value;
                totalPrice += (orderDetail.Quantity.Value * orderDetail.UnitPriceSale.Value);
            }

            ViewBag.TotalQuantity = totalQuantity;
            ViewBag.TotalPrice = totalPrice;
            //
            return View(orderDetails.OrderBy(x => x.ID).ToPagedList(pageNumber, pageSize));
        }
    }
}