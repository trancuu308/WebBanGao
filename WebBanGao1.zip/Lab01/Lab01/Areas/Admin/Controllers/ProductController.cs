﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;


namespace Lab01.Areas.Admin.Controllers
{
    public class ProductController : Controller
    {
        // GET: Admin/Product
        Shop1Entities _database = new Shop1Entities();
        // GET: Product
        public ActionResult Index(String searchBy, string search)


        {
            if (searchBy == "Available")
                return View(_database.Products.Where(s => s.Availbale == search).ToList());
            else if (searchBy == "NameProduct") // search == name product
            {
                return View(_database.Products.Where(s => s.NameProduct.StartsWith(search)).ToList());
            }
            else
                return View(_database.Products.ToList());
        }

        // GET: Product/Details/5
        public ActionResult Details(int id)
        {
            return View(_database.Products.Where(s => s.IDProduct == id).FirstOrDefault());
        }

        // GET: Product/Create
        public ActionResult Create()
        {
            Product pro = new Product();
            return View(pro);
        }

        // POST: Product/Create
        [HttpPost]
        public ActionResult Create(Product pro)
        {
            try
            {
                // TODO: Add insert logic here
                if (pro.ImageUpload != null)
                {
                    string filename = Path.GetFileNameWithoutExtension(pro.ImageUpload.FileName);
                    string extentions = Path.GetExtension(pro.ImageUpload.FileName);
                    filename = filename + extentions;
                    pro.Images = "~/Content/images/" + filename;
                    pro.ImageUpload.SaveAs(Path.Combine(Server.MapPath("~/Content/images/"), filename));
                }
                _database.Products.Add(pro);
                _database.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Product/Edit/5
        public ActionResult Edit(int id)
        {
            return View(_database.Products.Where(s => s.IDProduct == id).FirstOrDefault());
        }

        // POST: Product/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Product pro)
        {
            try
            {
                // TODO: Add insert logic here
                if (pro.ImageUpload != null)
                {
                    string filename = Path.GetFileNameWithoutExtension(pro.ImageUpload.FileName);
                    string extentions = Path.GetExtension(pro.ImageUpload.FileName);
                    filename = filename + extentions;
                    pro.Images = "~/Content/images/" + filename;
                    pro.ImageUpload.SaveAs(Path.Combine(Server.MapPath("~/Content/images/"), filename));
                }
                
                
                _database.Products.Add(pro);
                _database.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Product/Delete/5
        public ActionResult Delete(int id)
        {
            return View(_database.Products.Where(s => s.IDProduct == id).FirstOrDefault());
        }

        // POST: Product/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, Product pro)
        {
            try
            {
                pro = _database.Products.Where(s => s.IDProduct == id).FirstOrDefault();
                _database.Products.Remove(pro);
                _database.SaveChanges();
                return RedirectToAction("Index");
                // TODO: Add delete logic here
            }
            catch
            {
                return View("Index");
            }
        }
        public ActionResult ChooseCatetory()
        {
            Category cate = new Category();
            cate.CateCollection = _database.Categories.ToList<Category>();
            return PartialView(cate);
        }
    }
}