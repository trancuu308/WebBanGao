﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;

namespace Lab01.Areas.Admin.Controllers
{
    public class UsersController : Controller
    {
        Shop1Entities _db = new Shop1Entities();
        // GET: Admin/Customer
        public ActionResult Index(String searchBy, string search)


        {
            if (searchBy == "Phone_Cus")
                return View(_db.Users.Where(s => s.LastName == search).ToList());
            else if (searchBy == "Email_Cus") // search == email
            {
                return View(_db.Users.Where(s => s.Email.StartsWith(search)).ToList());
            }
            else
                return View(_db.Users.ToList());
        }

        // GET: Admin/users/Details/5
        public ActionResult Details(int id)
        {
            return View(_db.Users.Where(s => s.IDUser == id).FirstOrDefault());
        }

        // GET: Admin/Customer/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Admin/Customer/Create
        [HttpPost]
        public ActionResult Create(User cus)
        {
            try
            {
                // TODO: Add insert logic here
                _db.Users.Add(cus);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Admin/Customer/Edit/5
        public ActionResult Edit(int id)
        {
            return View(_db.Users.Where(s => s.IDUser == id).FirstOrDefault());
        }

        // POST: Admin/Customer/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, Category cus)
        {
            try
            {
                // TODO: Add update logic here
                _db.Entry(cus).State = System.Data.Entity.EntityState.Modified;
                _db.SaveChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Admin/Customer/Delete/5
        public ActionResult Delete(int id)
        {
            return View(_db.Users.Where(s => s.IDUser == id).FirstOrDefault());
        }

        // POST: Admin/Customer/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, User cus)
        {
            try
            {
                // TODO: Add delete logic here
                cus = _db.Users.Where(s => s.IDUser == id).FirstOrDefault();
                _db.Users.Remove(cus);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return Content("IDCus is used for other table");
            }
        }
    }
}
